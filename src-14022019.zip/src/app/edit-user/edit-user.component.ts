import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { User } from '../models';
import { AlertService, UserService } from '../services';
import { DialogData } from '../home';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {

  userProfile: FormGroup;
  loading = false;
  submitted = false;
  currentUser: User;
  users: User[] = [];
  userCopy = {};
  changedUser: User = new User();



  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data: DialogData
    , private userService: UserService,
    public dialogRef: MatDialogRef<EditUserComponent>) {
    this.userCopy = Object.freeze(data);
    console.log("injected data ")
    console.log(this.userCopy);
    this.currentUser = data;
    console.log(this.currentUser)

  }



  onSubmit() {

    console.log("submit has been called");
    console.log(this.userCopy);
    const id = this.userCopy['id'];
    console.log(id);

    console.log(this.userProfile.value);
    this.userProfile.value.username ? this.changedUser['username'] = this.userProfile.value.username : this.changedUser['username'] = this.userCopy['username'];
    this.userProfile.value.firstName ? this.changedUser['firstName'] = this.userProfile.value.firstName : this.changedUser['firstName'] = this.userCopy['firstName'];
    this.userProfile.value.lastName ? this.changedUser['lastName'] = this.userProfile.value.lastName : this.changedUser['lastName'] = this.userCopy['lastName'];
    this.userProfile.value.mobile ? this.changedUser['mobile'] = this.userProfile.value.mobile : this.changedUser['mobile'] = this.userCopy['mobile'];
    this.userProfile.value.email ? this.changedUser['email'] = this.userProfile.value.email : this.changedUser['email'] = this.userCopy['email'];
    this.changedUser['id'] = id;

    // const object2 = Object.assign({},this.userCopy, this.userProfile.value);
    // console.log(object2);
    console.log(this.changedUser);

    this.userService.delete( id ).pipe(first()).subscribe(() => {
      console.log('this id has been deleted');
    });
    
    this.userService.register(this.changedUser)
      .pipe(first())
      .subscribe(
        data => {
          console.log(data);
          this.dialogRef.close();
           window.location.reload();
        },
        error => {
          console.log(error);
        });
  }


  ngOnInit() {

    this.userProfile = this.formBuilder.group({
      firstName: '',
      lastName: '',
      username: '',
      email: '',
      mobile: '',

    });
  }
  // convenience getter for easy access to form fields
  get f() { return this.userProfile.controls; }

  closeDialog() {
    console.log('clsoing the dialog box ')
    this.dialogRef.close();
  }
}

