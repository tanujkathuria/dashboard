﻿import { Component, OnInit, ViewChild, Inject, AfterViewInit } from '@angular/core';
import { first } from 'rxjs/operators';

import { User } from '../models';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { UserService } from '../services';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { EditUserComponent } from '../edit-user/edit-user.component';
import { UserprofileComponent } from '../userprofile/userprofile.component';

export interface DialogData {
    id: number;
    username: string;
    password: string;
    firstName: string;
    lastName: string;
    email: string;
    mobile: string;
}




@Component(
    { selector: 'app-home', 
      templateUrl: 'home.component.html',
       styleUrls: ['./home.component.css'] })


export class HomeComponent implements OnInit  {
    

    currentUser: User;
    users: User[] = [];
    id: number;
    firstName: string;
    lastName: string;
    username: string;
    email: string;
    mobile: string;
    displayedColumns: string[] = ['Id', 'username', 'firstname', 'lastname', 'email', 'mobile', 'delete', 'edit'];
    dataSource;
    progressSpinner = true;

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;

    dialogRef;


    openDialog(element): void {

        console.log(element);
        this.dialogRef = this.dialog.open(EditUserComponent, {
            width: '1000px',
            height: '500px',
            data: { id: element.id, username: element.username, firstName: element.firstName, lastName: element.lastName, email: element.email, mobile: element.mobile }

        });

        this.dialogRef.afterClosed().subscribe(result => {
            console.log('The dialog was closed');
            this.users = result;
            console.log(result);

        });
    }


   

    constructor(public dialog: MatDialog,
        @Inject(MAT_DIALOG_DATA) public data: DialogData
        , private userService: UserService) {
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
       
    }

    ngOnInit() {
        this.progressSpinner = true;
         setTimeout(() => {
             this.progressSpinner = false;
             this.loadAllUsers();
           },5000);
        
    }

    editHandler(user: User) {
        console.log('item has been edit ' + user.username);
        this.userService.edit(user);


    }

    applyFilter(filterValue: string) {
        this.dataSource.filter = filterValue.trim().toLowerCase();
    }

    deleteUser(id: number) {
        this.userService.delete(id).pipe(first()).subscribe(() => {
            this.loadAllUsers()
        });
    }

    onNoClick(): void {
        this.dialogRef.close();
      }



    deleteHandler(username) {
        console.log(username)
        console.log('item has been deleted ')
      
        var found = this.users.find(function (element) {
            return element.username === username;
        });

        console.log(found);
        this.users.splice(this.users.indexOf(found, 0), 1);
        this.dataSource = new MatTableDataSource(this.users);
        console.log(this.dataSource);
        this.deleteUser(found.id);
    }

    private loadAllUsers() {
        this.userService.getAll().pipe(first()).subscribe(users => {
            this.users = users;
            this.dataSource = new MatTableDataSource(this.users);
            console.log(this.users);
            this.dataSource.paginator = this.paginator
            this.dataSource.sort = this.sort;
            console.log(this.dataSource);
        });
    }


}