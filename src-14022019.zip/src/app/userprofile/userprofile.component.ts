import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { User } from '../models';
import { AlertService, UserService } from '../services';
@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit {
  userProfile: FormGroup;
  loading = false;
  submitted = false;
  currentUser: User;
  users: User[] = [];
  constructor( private formBuilder: FormBuilder,
    private router: Router,
    private userService: UserService,
    
    private alertService: AlertService)  {
      this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
     }

  ngOnInit() {
    
    this.userProfile = this.formBuilder.group({
      firstName: '',
      lastName: '',
      username:'' ,
      email: '',
      mobile :'' ,
     
  });
  }
 // convenience getter for easy access to form fields
 get f() { return this.userProfile.controls; }


 
}
